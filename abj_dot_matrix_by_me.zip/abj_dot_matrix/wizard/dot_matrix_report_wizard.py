from odoo import models, fields, api, _
from odoo.exceptions import UserError
import logging
import urllib.parse

_logger = logging.getLogger(__name__)


class DotMatrixReportWizard(models.TransientModel):
    _name = 'dot.matrix.report.wizard'
    _description = 'Dot Matrix Report Wizard'

    document_type = fields.Selection([
        ('sale.order', 'Sale Order'),
        ('purchase.order', 'Purchase Order'),
        ('account.move', 'Invoice'),
        ('stock.picking', 'Stock Picking'),
    ], string='Document Type', required=True, readonly=True)
    
    document_id = fields.Integer('Document ID', required=True)
    document_name = fields.Char('Document Name', required=True, readonly=True)
    
    template_id = fields.Many2one('dot.matrix.template', string='Template', required=True)
    printer_id = fields.Many2one('dot.matrix.printer', string='Printer', required=True)
    preview_text = fields.Text('Preview', readonly=True)
    copies = fields.Integer('Number of Copies', default=1, min=1, max=10)
    show_preview = fields.Boolean('Show Preview', default=True)

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        if self.env.context.get('default_document_type'):
            document_type = self.env.context.get('default_document_type')
            res['document_type'] = document_type
            template = self.env['dot.matrix.template'].get_default_template(document_type)
            if template:
                res['template_id'] = template.id
            printer = self.env['dot.matrix.printer'].get_default_printer()
            if printer:
                res['printer_id'] = printer.id
        return res

    @api.onchange('template_id', 'document_id', 'show_preview')
    def _onchange_template(self):
        if self.template_id and self.document_id and self.show_preview:
            self.preview_text = self._generate_preview()
        else:
            self.preview_text = ''

    def _generate_preview(self):
        try:
            document_model = self.env[self.document_type]
            document = document_model.browse(self.document_id)
            if not document.exists():
                return "Document not found"
            # Panggil fungsi Jinja2 yang benar
            return self.template_id.generate_report_jinja(document)
        except Exception as e:
            _logger.error(f"Error generating preview: {str(e)}")
            return f"Error generating preview: {str(e)}"

    def action_print(self):
        self.ensure_one()
        document = self.env[self.document_type].browse(self.document_id)
        if not document.exists():
            raise UserError(_('Document not found'))
        # Panggil fungsi Jinja2 yang benar
        report_content = self.template_id.generate_report_jinja(document)
        
        success_count = 0
        for i in range(self.copies):
            success = self.printer_id.print_report(report_content, self.template_id)
            if success:
                success_count += 1
        
        if success_count > 0:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Success'),
                    'message': _('%d copy(ies) printed successfully on %s') % (success_count, self.printer_id.name),
                    'type': 'success',
                }
            }
        else:
            raise UserError(_('Failed to print report on %s') % self.printer_id.name)

    def action_download(self):
        self.ensure_one()
        document = self.env[self.document_type].browse(self.document_id)
        if not document.exists():
            raise UserError(_('Document not found'))
        # Panggil fungsi Jinja2 yang benar
        report_content = self.template_id.generate_report_jinja(document)
        
        if self.document_type == 'sale.order':
            filename = f"Sale_Order_{self.document_name}_{document.date_order.strftime('%Y%m%d') if document.date_order else 'NoDate'}.txt"
        elif self.document_type == 'purchase.order':
            filename = f"Purchase_Order_{self.document_name}_{document.date_order.strftime('%Y%m%d') if document.date_order else 'NoDate'}.txt"
        elif self.document_type == 'account.move':
            filename = f"Invoice_{self.document_name}_{document.invoice_date.strftime('%Y%m%d') if document.invoice_date else 'NoDate'}.txt"
        elif self.document_type == 'stock.picking':
            filename = f"Stock_Picking_{self.document_name}_{document.scheduled_date.strftime('%Y%m%d') if document.scheduled_date else 'NoDate'}.txt"
        else:
            filename = f"Dot_Matrix_{self.document_name}.txt"
        
        encoded_content = urllib.parse.quote(report_content)
        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content/dot_matrix_download?filename={filename}&content={encoded_content}',
            'target': 'self'
        }

    def action_preview(self):
        self.ensure_one()
        preview_content = self._generate_preview()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Report Preview'),
            'res_model': 'dot.matrix.preview.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_preview_text': preview_content,
                'default_document_name': self.document_name,
            }
        }

    def action_test_printer(self):
        self.ensure_one()
        return self.printer_id.action_test_print()


# ===================================================================
# == KELAS YANG HILANG SEBELUMNYA, SEKARANG SUDAH ADA KEMBALI ==
# ===================================================================
class DotMatrixPreviewWizard(models.TransientModel):
    _name = 'dot.matrix.preview.wizard'
    _description = 'Dot Matrix Preview Wizard'

    preview_text = fields.Text('Preview Text', readonly=True)
    document_name = fields.Char('Document Name', readonly=True)

    def action_print_preview(self):
        self.ensure_one()
        printer = self.env['dot.matrix.printer'].get_default_printer()
        if not printer:
            raise UserError(_('No default printer configured'))
        
        success = printer.print_report(self.preview_text)
        if success:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Success'),
                    'message': _('Preview printed successfully on %s') % printer.name,
                    'type': 'success',
                }
            }
        else:
            raise UserError(_('Failed to print preview on %s') % printer.name)

    def action_download_preview(self):
        self.ensure_one()
        filename = f"Dot_Matrix_Preview_{self.document_name}.txt"
        encoded_content = urllib.parse.quote(self.preview_text)
        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content/dot_matrix_download?filename={filename}&content={encoded_content}',
            'target': 'self'
        }