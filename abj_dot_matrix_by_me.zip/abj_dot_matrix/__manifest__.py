{
    'name': 'Abajoo - Dot Matrix Report',
    'version': '1.0.0',
    'summary': 'Enables printing of reports in a dot matrix format using editable templates.',
    'description': """
        This module provides the functionality to print reports in a text-based format 
        suitable for dot matrix printers.

        Supported Documents:
        - Sale Orders
        - Purchase Orders
        - Invoices (Customer & Vendor)
        - Stock Pickings (Delivery & Receipt)

        Features:
        - Flexible template system with variables
        - Easy configuration through UI
        - Support for multiple printer configurations
        - Customizable header, body, and footer sections
        - Preview functionality before printing
    """,
    'author': 'Abajoo',
    'website': 'https://abajoo.co.id',
    'category': 'Reporting',
    'depends': [
        'sale_management',
        'purchase',
        'account',
        'stock',
        'mail',
        'base',
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/dot_matrix_data.xml',
        'data/dot_matrix_table_template.xml',
        'data/dot_matrix_invoice_template.xml',
        'report/report_action.xml',
        'views/dot_matrix_template_views.xml',
        'views/dot_matrix_printer_views.xml',
        'views/menu_views.xml',
        'wizard/dot_matrix_report_wizard_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'abj_dot_matrix/static/src/js/dot_matrix_preview.js',
            'abj_dot_matrix/static/src/css/dot_matrix.css',
            'abj_dot_matrix/static/src/xml/dot_matrix_preview.xml',
        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}