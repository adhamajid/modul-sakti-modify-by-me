/** @odoo-module **/

import { Component, useState, onMounted } from "@odoo/owl";

export class DotMatrixPreview extends Component {
    setup() {
        this.state = useState({
            content: this.props.content || '',
            paperWidth: this.props.paperWidth || 80,
            paperHeight: this.props.paperHeight || 66,
        });
        
        onMounted(() => {
            this._renderPreview();
        });
    }

    _renderPreview() {
        const previewElement = this.root.querySelector('.dot-matrix-text');
        if (previewElement) {
            previewElement.textContent = this.state.content;
        }
    }

    // Method to update content
    updateContent(content) {
        this.state.content = content;
    }

    // Method to update paper dimensions
    updatePaperDimensions(width, height) {
        this.state.paperWidth = width;
        this.state.paperHeight = height;
    }
}

DotMatrixPreview.template = 'abj_dot_matrix.DotMatrixPreview';
DotMatrixPreview.props = {
    content: { type: String, optional: true },
    paperWidth: { type: Number, optional: true },
    paperHeight: { type: Number, optional: true },
};

// Register the component
import { registry } from "@web/core/registry";
registry.category("components").add("DotMatrixPreview", DotMatrixPreview); 