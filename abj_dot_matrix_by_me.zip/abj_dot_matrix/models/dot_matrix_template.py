from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import re
import json
import textwrap
from jinja2 import Environment, BaseLoader


class DotMatrixTemplate(models.Model):
    _name = 'dot.matrix.template'
    _description = 'Dot Matrix Template'
    _order = 'name'

    name = fields.Char('Template Name', required=True)
    active = fields.Boolean('Active', default=True)
    document_type = fields.Selection([
        ('sale.order', 'Sale Order'),
        ('purchase.order', 'Purchase Order'),
        ('account.move', 'Invoice'),
        ('stock.picking', 'Stock Picking'),
    ], string='Document Type', required=True)
    
    printer_id = fields.Many2one('dot.matrix.printer', string='Default Printer')
    paper_width = fields.Integer('Paper Width (chars)', default=80)
    paper_height = fields.Integer('Paper Height (lines)', default=66)
    
    # Template sections
    header_template = fields.Text('Header Template', help="Template for header section")
    body_template = fields.Text('Body Template', help="Template for body section")
    footer_template = fields.Text('Footer Template', help="Template for footer section")
    
    # Configuration
    font_family = fields.Selection([
        ('courier', 'Courier'),
        ('monospace', 'Monospace'),
    ], string='Font Family', default='courier')
    
    font_size = fields.Selection([
        ('small', 'Small (8pt)'),
        ('medium', 'Medium (10pt)'),
        ('large', 'Large (12pt)'),
    ], string='Font Size', default='medium')
    
    # Variables available for this template
    variable_ids = fields.One2many('dot.matrix.variable', 'template_id', string='Available Variables')
    
    # Sample data for preview
    sample_data = fields.Text('Sample Data (JSON)', help="Sample data for preview in JSON format")
    
    # Template preview
    preview_text = fields.Text('Preview', readonly=True, compute='_compute_preview')
    
    _sql_constraints = [
        ('name_uniq', 'unique(name)', 'Template name must be unique!')
    ]

    @api.depends('header_template', 'body_template', 'footer_template', 'sample_data')
    def _compute_preview(self):
        for template_record in self:
            # Pengecekan awal, jika tidak ada sample data, kosongkan preview
            if not template_record.sample_data:
                template_record.preview_text = "No sample data available"
                continue # Lanjut ke record berikutnya jika ada

            try:
                # 1. Ubah sample data JSON Anda menjadi dictionary Python.
                # Dictionary ini akan menjadi 'context' untuk Jinja2.
                context = json.loads(template_record.sample_data)

                # 2. Panggil 'render_jinja_template' untuk setiap bagian template.
                # Metode ini lebih sederhana dan cocok karena langsung menerima dictionary.
                rendered_header = template_record.render_jinja_template(template_record.header_template, context)
                rendered_body = template_record.render_jinja_template(template_record.body_template, context)
                rendered_footer = template_record.render_jinja_template(template_record.footer_template, context)

                # 3. Gabungkan semua bagian yang sudah dirender menjadi satu string utuh.
                # filter(None, ...) digunakan untuk menghapus bagian yang kosong.
                template_record.preview_text = "\n".join(filter(None, [rendered_header, rendered_body, rendered_footer]))

            except Exception as e:
                template_record.preview_text = "Error generating Jinja2 preview: %s" % str(e)

    @api.model
    def _render_template(self, template, data):
        """Render template with given data"""
        result = ""
        
        # Render header
        if template.header_template:
            result += self._render_section(template.header_template, data) + "\n"
        
        # Render body
        if template.body_template:
            result += self._render_section(template.body_template, data) + "\n"
        
        # Render footer
        if template.footer_template:
            result += self._render_section(template.footer_template, data)
        
        return result

    @api.model
    def _render_section(self, template_text, data):
        """Render a section of the template"""
        if not template_text:
            return ""

        # Proses loop terlebih dahulu agar placeholder di dalam loop bisa di-render
        result = self._process_loops(template_text, data)

        # Proses conditional
        result = self._process_conditionals(result, data)

        # Fungsi rekursif untuk mencari dan mengganti placeholder dengan dot notation, misal {{order.name}}
        def replace_dot_notation(match):
            expr = match.group(1).strip()
            value = self._get_value_from_data(expr, data)
            return str(value) if value is not None else ""

        # Ganti semua {{ ... }} dengan value yang sesuai, support dot notation
        result = re.sub(r"\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}", replace_dot_notation, result)

        return result

    def _get_value_from_data(self, expr, data):
        """Ambil value dari data dict dengan support dot notation, misal 'order.name'"""
        keys = expr.split('.')
        val = data
        for key in keys:
            if isinstance(val, dict):
                val = val.get(key)
            elif isinstance(val, list):
                try:
                    idx = int(key)
                    val = val[idx]
                except (ValueError, IndexError):
                    return None
            else:
                return None
            if val is None:
                return None
        return val

    @api.model
    def _process_loops(self, text, data):
        """Process loop statements in template"""
        # Pola: {% for item in items %} ... {% endfor %}
        loop_pattern = r'\{%\s*for\s+(\w+)\s+in\s+([a-zA-Z0-9_\.]+)\s*%\}(.*?)\{%\s*endfor\s*%\}'
        # Pola untuk tabel hardcode: {% for item in items:10 %} ... {% endfor %}
        hardcode_loop_pattern = r'\{%\s*for\s+(\w+)\s+in\s+([a-zA-Z0-9_\.]+):(\d+)\s*%\}(.*?)\{%\s*endfor\s*%\}'

        def replace_loop(match):
            var_name = match.group(1)
            list_expr = match.group(2)
            loop_content = match.group(3)

            items = self._get_value_from_data(list_expr, data)
            if isinstance(items, list):
                result = ""
                for item in items:
                    # Buat context baru dengan variable loop
                    # Gunakan copy mendalam agar nested loop/variable tidak saling overwrite
                    if isinstance(data, dict):
                        loop_data = dict(data)
                    else:
                        loop_data = {}
                    loop_data[var_name] = item
                    # Render isi loop dengan context baru
                    result += self._render_section(loop_content, loop_data)
                return result
            return ""

        def replace_hardcode_loop(match):
            var_name = match.group(1)
            list_expr = match.group(2)
            max_rows = int(match.group(3))
            loop_content = match.group(4)

            items = self._get_value_from_data(list_expr, data)
            if isinstance(items, list):
                result = ""
                for row_num in range(max_rows):
                    if row_num < len(items):
                        # Ada data item
                        item = items[row_num]
                        if isinstance(data, dict):
                            loop_data = dict(data)
                        else:
                            loop_data = {}
                        loop_data[var_name] = item
                        result += self._render_section(loop_content, loop_data)
                    else:
                        # Baris kosong untuk melengkapi tabel
                        if isinstance(data, dict):
                            loop_data = dict(data)
                        else:
                            loop_data = {}
                        # Buat item kosong untuk baris kosong
                        empty_item = {'formatted_line': '║   ║               ║                              ║           ║       ║'}
                        loop_data[var_name] = empty_item
                        result += self._render_section(loop_content, loop_data)
                return result
            return ""

        # Proses hardcode loop terlebih dahulu
        prev_text = None
        while prev_text != text:
            prev_text = text
            text = re.sub(hardcode_loop_pattern, replace_hardcode_loop, text, flags=re.DOTALL)

        # Proses loop biasa
        prev_text = None
        while prev_text != text:
            prev_text = text
            text = re.sub(loop_pattern, replace_loop, text, flags=re.DOTALL)
        return text

    @api.model
    def _process_conditionals(self, text, data):
        """Process conditional statements in template"""
        # Pola: {% if condition %} ... {% endif %}
        if_pattern = r'\{%\s*if\s+([a-zA-Z0-9_\.]+)\s*%\}(.*?)\{%\s*endif\s*%\}'

        def replace_conditional(match):
            condition_expr = match.group(1)
            content = match.group(2)
            cond_value = self._get_value_from_data(condition_expr, data)
            if cond_value:
                return self._render_section(content, data)
            return ""

        # Gunakan re.sub untuk mendukung nested if (rekursif)
        prev_text = None
        while prev_text != text:
            prev_text = text
            text = re.sub(if_pattern, replace_conditional, text, flags=re.DOTALL)
        return text

    def generate_report(self, record):
        """Generate report for a specific record"""
        data = self._prepare_data(record)
        return self._render_template(self, data)

    def render_jinja_template(self, template_str, context):
        """
        Render template string menggunakan Jinja2 dengan context dict.
        """
        env = Environment(loader=BaseLoader())
        template = env.from_string(template_str or "")
        return template.render(context)

    def generate_report_jinja(self, record):
        """
        Generate report menggunakan Jinja2 untuk template header, body, dan footer.
        """
        # Siapkan data context
        if self.document_type == 'sale.order':
            data = self._prepare_sale_order_data(record)
        elif self.document_type == 'purchase.order':
            data = self._prepare_purchase_order_data(record)
        elif self.document_type == 'account.move':
            data = self._prepare_invoice_data(record)
        elif self.document_type == 'stock.picking':
            data = self._prepare_stock_picking_data(record)
        else:
            data = {}

        # Render header
        rendered_header = self.render_jinja_template(self.header_template, data)
        # Render body (langsung, karena Jinja2 support loop)
        rendered_body = self.render_jinja_template(self.body_template, data)
        # Render footer
        rendered_footer = self.render_jinja_template(self.footer_template, data)

        # Gabungkan hasil
        return "".join([rendered_header, rendered_body, rendered_footer])

    @api.model
    def _prepare_data(self, record):
        """Prepare data for template rendering based on document type"""
        if self.document_type == 'sale.order':
            return self._prepare_sale_order_data(record)
        elif self.document_type == 'purchase.order':
            return self._prepare_purchase_order_data(record)
        elif self.document_type == 'account.move':
            return self._prepare_invoice_data(record)
        elif self.document_type == 'stock.picking':
            return self._prepare_stock_picking_data(record)
        return {}

    @api.model
    def _prepare_sale_order_data(self, order):
        """Prepare data for sale order"""
        return {
            'order': {
                'name': order.name,
                'date_order': order.date_order.strftime('%Y-%m-%d') if order.date_order else '',
                'partner_ref': '',
                'amount_total': order.amount_total,
                'currency_symbol': order.currency_id.symbol,
            },
            'customer': {
                'name': order.partner_id.name,
                'street': order.partner_id.street or '',
                'city': order.partner_id.city or '',
                'phone': order.partner_id.phone or '',
                'email': order.partner_id.email or '',
            },
            'items': [{
                'name': line.product_id.name,
                'description': line.name,
                'qty': line.product_uom_qty,
                'price': line.price_unit,
                'subtotal': line.price_subtotal,
            } for line in order.order_line],
            'total_amount': order.amount_total,
            'tax_amount': order.amount_tax,
            'untaxed_amount': order.amount_untaxed,
        }

    @api.model
    def _prepare_purchase_order_data(self, order):
        """Prepare data for purchase order"""
        return {
            'order': {
                'name': order.name,
                'date_order': order.date_order.strftime('%Y-%m-%d') if order.date_order else '',
                'partner_ref': order.partner_ref or '',
                'amount_total': order.amount_total,
                'currency_symbol': order.currency_id.symbol,
            },
            'supplier': {
                'name': order.partner_id.name,
                'street': order.partner_id.street or '',
                'city': order.partner_id.city or '',
                'phone': order.partner_id.phone or '',
                'email': order.partner_id.email or '',
            },
            'items': [{
                'name': line.product_id.name,
                'description': line.name,
                'qty': line.product_qty,
                'price': line.price_unit,
                'subtotal': line.price_subtotal,
            } for line in order.order_line],
            'total_amount': order.amount_total,
            'tax_amount': order.amount_tax,
            'untaxed_amount': order.amount_untaxed,
        }

    @api.model
    def _prepare_invoice_data(self, invoice):
        """Prepare data for invoice"""
        company = self.env.company

        return {
            'company': {
                'name': invoice.company_id.name,
                'street': invoice.company_id.street or '',
                'street2': invoice.company_id.street2 or '',
                'city': invoice.company_id.city or '',
                'country': invoice.company_id.country_id.name or '',
                'zip': invoice.company_id.zip or '',
                'phone': invoice.company_id.phone or '',
                'email': invoice.company_id.email or '',
                'website': invoice.company_id.website or '',
            },
            'partner': {
                'name': invoice.partner_id.name,
                'street': invoice.partner_id.street or '',
                'street2': invoice.partner_id.street2 or '',
                'city': invoice.partner_id.city or '',
                'country': invoice.partner_id.country_id.name or '',
                'zip': invoice.partner_id.zip or '',
                'phone': invoice.partner_id.phone or '',
                'email': invoice.partner_id.email or '',
            },
            'invoice': {
                'name': invoice.name,
                'invoice_date': invoice.invoice_date.strftime('%Y-%m-%d') if invoice.invoice_date else '',
                'invoice_date_due': invoice.invoice_date_due.strftime('%Y-%m-%d') if invoice.invoice_date_due else '',
                'amount_untaxed': invoice.amount_untaxed,
                'amount_tax': invoice.amount_tax,
                'amount_total': invoice.amount_total,
            },
            'items': [{
                'name': line.product_id.name if line.product_id else '',
                'description': line.name,
                'quantity': line.quantity,
                'price_unit': line.price_unit,
                'price_subtotal': line.price_subtotal,
            } for line in invoice.invoice_line_ids],
        }

    @api.model
    def _prepare_stock_picking_data(self, picking):
        """
        Menyiapkan dan memformat data untuk struk dot matrix.
        FINAL: Mengambil data dari stock.move.line untuk Lot/SN dan Kuantitas.
        """
        company = self.env.company
        
        full_address_parts = [
            picking.partner_id.street,
            picking.partner_id.street2,
            picking.partner_id.city,
            picking.partner_id.state_id.name,
            picking.partner_id.zip,
            picking.partner_id.country_id.name,
        ]
        single_line_address = ', '.join(part for part in full_address_parts if part)

        # 2. Potong string menjadi beberapa baris dengan lebar maksimal 70 karakter
        max_width = 70
        wrapped_address_lines = textwrap.wrap(single_line_address, width=max_width)

        # 3. Siapkan dua variabel untuk dua baris alamat
        address_line_1 = wrapped_address_lines[0] if len(wrapped_address_lines) > 0 else ''
        address_line_2 = wrapped_address_lines[1] if len(wrapped_address_lines) > 1 else ''
        # ------------------------------------

        display_date_val = None
        if picking.state == 'done' and picking.date_done:
            # Prioritas 1: Tanggal selesai jika status 'Done'
            display_date_val = picking.date_done
        
        if not display_date_val and picking.scheduled_date:
            # Prioritas 2: Tanggal terjadwal jika tanggal selesai tidak ada
            display_date_val = picking.scheduled_date

        if not display_date_val:
            # Prioritas 3 (Fallback): Tanggal dokumen dibuat jika tidak ada tanggal lain
            display_date_val = picking.create_date

        # Format tanggal jika ada nilainya
        display_date_str = display_date_val.strftime('%d %B %Y') if display_date_val else ''

        # Ambil data item yang ada
        items_list = []
        is_done = picking.state == 'done'
        source_lines = picking.move_line_ids_without_package if is_done else picking.move_ids_without_package

        for line in source_lines:
            if is_done:
                # Jika state 'done', ambil dari move line dan parent move-nya
                qty_demand = line.move_id.product_uom_qty or 0
                qty_done = line.quantity or 0
            else: # Jika state 'draft' atau lainnya
                qty_demand = line.product_uom_qty or 0
                qty_done = 0

            items_list.append({
                'name': line.product_id.name or '',
                'qty_demand': qty_demand,
                'qty_done': qty_done
                # Tambahkan field lain jika perlu, misal 'code', 'lot', dll.
            })

        return {
            'picking': {
                'name': picking.name,
                'display_date': display_date_str,
                'origin': picking.origin or '',
            },
            'partner': {
                'name': picking.partner_id.name if picking.partner_id else '',
                'phone': picking.partner_id.phone or '',
                'address_line_1': address_line_1,
                'address_line_2': address_line_2,
                
            },
            'company': {
                'partner_id': {'city': company.partner_id.city or 'Jakarta'}
            },
            'items': items_list,
            'total_items': len(items_list),
        }

    @api.model
    def _create_table_border(self, style='double'):
        """Create continuous table border lines"""
        if style == 'double':
            # Menggunakan karakter Unicode untuk garis ganda yang kontinu
            horizontal_line = '═' * 80  # Garis horizontal ganda
            vertical_separator = '║'     # Garis vertikal ganda
            cross_separator = '╬'        # Persimpangan garis ganda
            left_corner = '╔'            # Sudut kiri atas
            right_corner = '╗'           # Sudut kanan atas
            left_bottom = '╚'            # Sudut kiri bawah
            right_bottom = '╝'           # Sudut kanan bawah
        else:
            # Fallback ke karakter ASCII jika Unicode tidak didukung
            horizontal_line = '=' * 80
            vertical_separator = '|'
            cross_separator = '+'
            left_corner = '+'
            right_corner = '+'
            left_bottom = '+'
            right_bottom = '+'
        
        return {
            'horizontal': horizontal_line,
            'vertical': vertical_separator,
            'cross': cross_separator,
            'left_corner': left_corner,
            'right_corner': right_corner,
            'left_bottom': left_bottom,
            'right_bottom': right_bottom
        }

    @api.model
    def _create_table_header(self, headers, border_style='double'):
        """Create table header with continuous borders"""
        borders = self._create_table_border(border_style)
        
        # Header row dengan garis vertikal kontinu
        header_line = f"{borders['vertical']}"
        for i, header in enumerate(headers):
            if i == 0:  # NO
                header_line += f"{header.center(3)}{borders['vertical']}"
            elif i == 1:  # PRODUCT CODE
                header_line += f"{header.center(15)}{borders['vertical']}"
            elif i == 2:  # PRODUCT NAME
                header_line += f"{header.center(30)}{borders['vertical']}"
            elif i == 3:  # LOT/SN
                header_line += f"{header.center(10)}{borders['vertical']}"
            elif i == 4:  # QTY
                header_line += f"{header.center(8)}{borders['vertical']}"
        
        # Top border
        top_border = f"{borders['left_corner']}{'═' * 3}{borders['cross']}{'═' * 15}{borders['cross']}{'═' * 30}{borders['cross']}{'═' * 10}{borders['cross']}{'═' * 8}{borders['right_corner']}"
        
        # Bottom border
        bottom_border = f"{borders['left_bottom']}{'═' * 3}{borders['cross']}{'═' * 15}{borders['cross']}{'═' * 30}{borders['cross']}{'═' * 10}{borders['cross']}{'═' * 8}{borders['right_bottom']}"
        
        return {
            'top': top_border,
            'header': header_line,
            'bottom': bottom_border
        }

    @api.model
    def get_default_template(self, document_type):
        """Get default template for document type"""
        return self.search([
            ('document_type', '=', document_type),
            ('active', '=', True)
        ], limit=1)